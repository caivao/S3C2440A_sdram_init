#ifndef _S3C2440A_H
#define _S3C2440A_H
/* S3C2440 寄存器定义 */

/* 看门狗 */
#define pWTCON          0x53000000

/* 中断屏蔽控制寄存器地址 */
#define INTMSK          0x4A000008 

/* 时钟分频配置寄存器 */
#define CLKDIVN	        0x4C000014
#define DIVN_UPLL       0x0
#define HDIVN           0x2
#define PDIVN           0x1

/* PLL 控制寄存器(MPLLCON 和 UPLLCON) */
#define MPLLCON         0x4C000004 /* MPLL 配置寄存器 */
#define M_MDIV          0x7d     
#define M_PDIV          0x1
#define M_SDIV          0x1

#define UPLLCON         0x4C000008 /* UPLL 配置寄存器 */
#define U_MDIV          0x38
#define U_PDIV          0x2
#define U_SDIV          0x2

/* sdram 相关寄存器定义 */
#define BWSCON	        0x48000000
#define SDRAM_BASE      0x30000000

/* BWSCON */
#define DW8			    (0x0)
#define DW16			(0x1)
#define DW32			(0x2)
#define WAIT			(0x1<<2)
#define UBLB			(0x1<<3)

#define B1_BWSCON		(DW32)
#define B2_BWSCON		(DW16)
#define B3_BWSCON		(DW16 + WAIT + UBLB)
#define B4_BWSCON		(DW16)
#define B5_BWSCON		(DW16)
#define B6_BWSCON		(DW32)
#define B7_BWSCON		(DW32)

/* BANK0CON */
#define B0_Tacs			0x0	/*  0clk */
#define B0_Tcos			0x0	/*  0clk */
#define B0_Tacc			0x7	/* 14clk */
#define B0_Tcoh			0x0	/*  0clk */
#define B0_Tah			0x0	/*  0clk */
#define B0_Tacp			0x0
#define B0_PMC			0x0	/* normal */

/* BANK1CON */
#define B1_Tacs			0x0	/*  0clk */
#define B1_Tcos			0x0	/*  0clk */
#define B1_Tacc			0x7	/* 14clk */
#define B1_Tcoh			0x0	/*  0clk */
#define B1_Tah			0x0	/*  0clk */
#define B1_Tacp			0x0
#define B1_PMC			0x0

#define B2_Tacs			0x0
#define B2_Tcos			0x0
#define B2_Tacc			0x7
#define B2_Tcoh			0x0
#define B2_Tah			0x0
#define B2_Tacp			0x0
#define B2_PMC			0x0

#define B3_Tacs			0x0	/*  0clk */
#define B3_Tcos			0x3	/*  4clk */
#define B3_Tacc			0x7	/* 14clk */
#define B3_Tcoh			0x1	/*  1clk */
#define B3_Tah			0x0	/*  0clk */
#define B3_Tacp			0x3 /*  6clk */
#define B3_PMC			0x0	/* normal */

#define B4_Tacs			0x0	/*  0clk */
#define B4_Tcos			0x0	/*  0clk */
#define B4_Tacc			0x7	/* 14clk */
#define B4_Tcoh			0x0	/*  0clk */
#define B4_Tah			0x0	/*  0clk */
#define B4_Tacp			0x0
#define B4_PMC			0x0	/* normal */

#define B5_Tacs			0x0	/*  0clk */
#define B5_Tcos			0x0	/*  0clk */
#define B5_Tacc			0x7	/* 14clk */
#define B5_Tcoh			0x0	/*  0clk */
#define B5_Tah			0x0	/*  0clk */
#define B5_Tacp			0x0
#define B5_PMC			0x0	/* normal */

#define B6_MT			0x3	/* SDRAM */
#define B6_Trcd			0x1 /* 3clk */
#define B6_SCAN			0x1	/* 9bit */

#define B7_MT			0x3	/* SDRAM */
#define B7_Trcd			0x1	/* 3clk */
#define B7_SCAN			0x1	/* 9bit */

/* REFRESH parameter */
#define REFEN			0x1	/* Refresh enable */
#define TREFMD			0x0	/* CBR(CAS before RAS)/Auto refresh */
#define Trp			    0x0	/* 2clk */
#define Tsrc			0x3	/* 7clk */
#define REFCNT			0x400 /* period=7.8us, HCLK=133Mhz, (2048+1-7.8*133) */

#define GPFCON          0x56000050
#define GPFDAT          0x56000054
#define GPFUP           0x56000058

#endif /* _S3C2440A_H */