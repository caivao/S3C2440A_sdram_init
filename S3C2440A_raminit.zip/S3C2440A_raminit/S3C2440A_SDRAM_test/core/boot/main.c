#include "S3C2440A.h"

/* GPF io 管脚配置寄存器 */
typedef struct GPF_REG {
    unsigned long int _GPFCON;
    unsigned long int _GPFDAT;
    unsigned long int _GPFUP;
} volatile *GPIOF_REG_t;

#define GPF ((GPIOF_REG_t)0x56000050)

extern void init_gpf(void);
extern void blink(void);
extern void water_light(void);
extern void delay(unsigned long loops);

void boot(void) {
    init_gpf();
    water_light();
}

void init_gpf(void) {
    /* 使能 GPF4, GPF5, GPF6, GPF7 输出 */
    GPF->_GPFCON = 0x5500;
    // /* 关闭GPF口上拉 */
    GPF->_GPFUP  = 0xFF;
    // /* 高电平 关闭所有 led 灯 */
    GPF->_GPFDAT = 0xff;
}

void blink(void) {
    unsigned int led_on = 0xF;
    while(1) {
        GPF->_GPFDAT = (led_on << 4);
        led_on = ~led_on;
        delay(115);
    }
}

void water_light(void) {
    unsigned char led_index = 0;
    while(1) {
        int led_on = ~(0x1 << led_index);
        GPF->_GPFDAT = (led_on << 4);
        delay(115);
        led_index++;
        led_index %= 4;
    }
}

void delay(unsigned long loops) {
    loops *= 145000;
    __asm__ volatile ("1:\n"
	  "subs %0, %1, #1\n"
	  "bne 1b" : "=r" (loops) : "0" (loops));
}