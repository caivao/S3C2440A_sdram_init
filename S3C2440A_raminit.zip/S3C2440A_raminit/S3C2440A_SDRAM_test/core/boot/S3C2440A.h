#ifndef _S3C2440A_H
#define _S3C2440A_H
/* S3C2440 寄存器定义 */

/* 看门狗 */
#define pWTCON          0x53000000

/* 中断屏蔽控制寄存器地址 */
#define INTMSK          0x4A000008 

#define SDRAM_BASE      0x30000000

#define GPFCON          0x56000050
#define GPFDAT          0x56000054
#define GPFUP           0x56000058

#endif /* _S3C2440A_H */